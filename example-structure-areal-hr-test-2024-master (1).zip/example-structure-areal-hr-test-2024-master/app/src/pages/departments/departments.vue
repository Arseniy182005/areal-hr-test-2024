<script>
import DepartmentList from "../../modules/departments/widgets/department-list.vue";

export default {
  name: "departments",
  components: {DepartmentList}
}
</script>

<template>
<department-list/>
</template>

<style scoped>

</style>
