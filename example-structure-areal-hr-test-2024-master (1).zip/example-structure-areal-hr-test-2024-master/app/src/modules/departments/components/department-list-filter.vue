<script>
export default {
  name: "department-list-filter"
}
</script>

<template>

</template>

<style scoped>

</style>
