<script>
export default {
  name: "department-list-table"
}
</script>

<template>

</template>

<style scoped>

</style>
