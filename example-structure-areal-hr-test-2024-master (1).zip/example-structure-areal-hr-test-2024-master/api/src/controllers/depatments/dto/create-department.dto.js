export const createDepartmentDto = Joi.object({})
